# Documentação de Esquema e RPC Supabase (RAG Híbrido)

- **Data da Introspecção:** 2026-07-21T19:18:23.756234+00:00
- **Modelo de Embedding:** `text-embedding-3-large`
- **Dimensão:** `1536`
- **Métrica de Distância:** `cosine`

## Tabela `documents`
- `id` (bigint, PK)
- `content` (text)
- `metadata` (jsonb)
- `fts` (tsvector)
- `embedding` (vector(1536))

## Funções RPC Registradas
- `hybrid_search(query_text text, query_embedding vector(1536), match_count int)`
- `match_documents(query_embedding vector(1536), match_threshold float, match_count int)`

## Instruções de Rollback
Restaurar snapshot `documents_rows.csv` (120 linhas) se necessário. Não realizar alterações estruturais de DDL na produção.
